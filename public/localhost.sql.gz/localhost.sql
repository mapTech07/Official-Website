-- Adminer 4.8.1 MySQL 8.0.36-28 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `hotelmanagement-353039381ef3` /*!40100 DEFAULT CHARACTER SET latin1 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hotelmanagement-353039381ef3`;

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `category_status` enum('Enable','Disable') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Enable',
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `categories` (`category_id`, `category_name`, `category_status`) VALUES
(4,	'Beer',	'Enable'),
(7,	'Redbull',	'Enable'),
(9,	'Cold drinks and Eanergi drinks',	'Enable'),
(10,	'wine',	'Enable'),
(11,	'Applecider',	'Enable'),
(16,	'Rum',	'Enable'),
(17,	'Whisky',	'Enable');

DROP TABLE IF EXISTS `menu_category_table`;
CREATE TABLE `menu_category_table` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `category_status` enum('Enable','Disable') COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `menu_category_table` (`category_id`, `category_name`, `category_status`) VALUES
(6,	'TEA AND COFFEE',	'Enable'),
(7,	'BREAK FAST',	'Enable'),
(8,	'SET KHANA',	'Enable'),
(9,	'BEVARAGES AND SALAD',	'Enable'),
(10,	'SOUP NON VEG',	'Enable'),
(11,	'NOODLES',	'Enable'),
(12,	'CHICKEN MOMO',	'Enable'),
(13,	'FRY RICE',	'Enable'),
(14,	'BIRYANI',	'Enable'),
(15,	'ROOL',	'Enable'),
(16,	'SIZLER',	'Enable'),
(17,	'PULAO',	'Enable'),
(18,	'CHOPSI',	'Enable'),
(19,	'NEPALI SPECIAL NON VEG SNACKS',	'Enable'),
(20,	'NEPALI SPECIAL VEG SNACKS',	'Enable'),
(21,	'MAIN COURSE NON VEG SNACKS',	'Enable'),
(22,	'MAIN COURSE VEG SNACKS',	'Enable'),
(23,	'MAIN COURSE NON VEG CURRY',	'Enable'),
(24,	'MAIN COURSE VEG CURRY',	'Enable'),
(25,	'Cold drinks',	'Enable');

DROP TABLE IF EXISTS `menu_table`;
CREATE TABLE `menu_table` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `category_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `product_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `product_status` enum('Enable','Disable') COLLATE utf8mb3_unicode_ci NOT NULL,
  `product_image` varchar(2000) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `menu_table` (`product_id`, `category_name`, `product_name`, `product_price`, `product_status`, `product_image`) VALUES
(11,	'TEA AND COFFEE',	'MILK COFFEE',	120.00,	'Enable',	''),
(12,	'TEA AND COFFEE',	'BLACK COFFEE',	100.00,	'Enable',	''),
(13,	'TEA AND COFFEE',	'BLACK TEA',	30.00,	'Enable',	''),
(14,	'TEA AND COFFEE',	'MILK TEA',	50.00,	'Enable',	''),
(15,	'TEA AND COFFEE',	'LEMON TEA',	40.00,	'Enable',	''),
(16,	'TEA AND COFFEE',	'HOT LEMON WITH HONEY',	180.00,	'Enable',	''),
(17,	'TEA AND COFFEE',	'HOT MILK',	100.00,	'Enable',	''),
(18,	'BREAK FAST',	'AALU PARATHA WITH CORD',	200.00,	'Enable',	''),
(19,	'BREAK FAST',	'AALU PARATHA WITH OUT CORD',	150.00,	'Enable',	''),
(20,	'BREAK FAST',	'PAN CAKE WITH HONEY',	200.00,	'Enable',	''),
(21,	'BREAK FAST',	'CORN FLACKS WITH MILK',	200.00,	'Enable',	''),
(22,	'BREAK FAST',	'OMELET OR JAM TOST',	200.00,	'Enable',	''),
(23,	'BREAK FAST',	'BUTTER JAM TOST WITH OMLET',	250.00,	'Enable',	''),
(24,	'BREAK FAST',	'MASALA OMELET',	150.00,	'Enable',	''),
(25,	'BREAK FAST',	'PLAIN OMELET',	100.00,	'Enable',	''),
(26,	'BREAK FAST',	'BOILED EGG 2 PES',	80.00,	'Enable',	''),
(27,	'BREAK FAST',	'WAIWAI CHICKEN SOUP',	100.00,	'Enable',	''),
(28,	'BREAK FAST',	'TAWA ROTI SABJI',	200.00,	'Enable',	''),
(29,	'SET KHANA',	'VEG SET KHANA with ghee',	300.00,	'Enable',	''),
(30,	'SET KHANA',	'VEG SET KHANA  without ghee',	280.00,	'Enable',	''),
(31,	'SET KHANA',	'CHICKEN SET KHANA LOCAL',	500.00,	'Enable',	''),
(32,	'SET KHANA',	'CHICKEN SET KHANA LOCAL with ghee and cord',	550.00,	'Enable',	''),
(33,	'SET KHANA',	'MUTTON SET KHANA',	500.00,	'Enable',	''),
(34,	'SET KHANA',	'FISH SET KHANA',	450.00,	'Enable',	''),
(35,	'SET KHANA',	'PORK SET KHANA',	450.00,	'Enable',	''),
(36,	'SET KHANA',	'MOUNTAIN NEPALI SPECIAL SET KHANA',	700.00,	'Enable',	''),
(37,	'SET KHANA',	'ROTI SET',	350.00,	'Enable',	''),
(38,	'SET KHANA',	'PLAIN RICE',	100.00,	'Enable',	''),
(39,	'BEVARAGES AND SALAD',	'SWEET LASSI',	150.00,	'Enable',	''),
(40,	'BEVARAGES AND SALAD',	'FRESH LIME SODA',	100.00,	'Enable',	''),
(41,	'BEVARAGES AND SALAD',	'PLAIN CURD',	80.00,	'Enable',	''),
(42,	'BEVARAGES AND SALAD',	'GREEN SALAD',	180.00,	'Enable',	''),
(43,	'BEVARAGES AND SALAD',	'NEPALI SALAD',	180.00,	'Enable',	''),
(44,	'BEVARAGES AND SALAD',	'MIX FRUIT SALAD',	250.00,	'Enable',	''),
(45,	'SOUP NON VEG',	'MUSHROOM SOUP VEG',	200.00,	'Enable',	''),
(46,	'SOUP NON VEG',	'MUSHROOM SOUP CHICKEN',	220.00,	'Enable',	''),
(47,	'SOUP NON VEG',	'HOT AND SOUR SOUP VEG',	220.00,	'Enable',	''),
(48,	'SOUP NON VEG',	'HOT AND SOUR SOUP CHICKEN',	250.00,	'Enable',	''),
(49,	'SOUP NON VEG',	'LEMON CORENDER SOUP VEG',	230.00,	'Enable',	''),
(50,	'SOUP NON VEG',	'LEMON CORENDER SOUP CHICKEN',	250.00,	'Enable',	''),
(51,	'SOUP NON VEG',	'TOMATO SOUP',	250.00,	'Enable',	''),
(52,	'NOODLES',	'NOODLES CHAUMIN VEG',	150.00,	'Enable',	''),
(53,	'NOODLES',	'NOODLES CHAUMIN CHICKEN',	180.00,	'Enable',	''),
(54,	'NOODLES',	'NOODLES CHAUMIN MUTTON',	200.00,	'Enable',	''),
(55,	'NOODLES',	'NOODLES CHAUMIN PORK',	170.00,	'Enable',	''),
(56,	'NOODLES',	'NOODLES CHAUMIN MIX',	280.00,	'Enable',	''),
(57,	'NOODLES',	'GARLIC NOODLES VEG',	180.00,	'Enable',	''),
(58,	'NOODLES',	'GARLIC NOODLES CHICKEN',	200.00,	'Enable',	''),
(59,	'NOODLES',	'GARLIC NOODLES MUTTON',	250.00,	'Enable',	''),
(60,	'NOODLES',	'GARLIC NOODLES PORK',	200.00,	'Enable',	''),
(61,	'NOODLES',	'GARLIC NOODLES MIX',	300.00,	'Enable',	''),
(62,	'NOODLES',	'SEZWAN NOODLES VEG',	200.00,	'Enable',	''),
(63,	'NOODLES',	'SEZWAN NOODLES CHICKEN',	220.00,	'Enable',	''),
(64,	'NOODLES',	'SEZWAN NOODLES MUTTON',	380.00,	'Enable',	''),
(65,	'NOODLES',	'SEZWAN NOODLES PORK',	200.00,	'Enable',	''),
(66,	'NOODLES',	'SEZWAN NOODLES MIX',	350.00,	'Enable',	''),
(67,	'NOODLES',	'NOODLES THUKPA VEG',	150.00,	'Enable',	''),
(68,	'NOODLES',	'NOODLES THUKPA CHICKEN',	180.00,	'Enable',	''),
(69,	'NOODLES',	'NOODLES THUKPA MUTTON',	200.00,	'Enable',	''),
(70,	'NOODLES',	'NOODLES THUKPA PORK',	220.00,	'Enable',	''),
(71,	'NOODLES',	'NOODLES THUKPA MIX',	350.00,	'Enable',	''),
(72,	'CHICKEN MOMO',	'STEAM MOMO',	200.00,	'Enable',	''),
(73,	'CHICKEN MOMO',	'CHILLY MOMO',	250.00,	'Enable',	''),
(74,	'CHICKEN MOMO',	'KOTHEY MOMO',	230.00,	'Enable',	''),
(75,	'CHICKEN MOMO',	'FRIED MOMO',	220.00,	'Enable',	''),
(76,	'FRY RICE',	'VEG FRY RICE',	200.00,	'Enable',	''),
(77,	'FRY RICE',	'CHICKEN FRY RICE',	250.00,	'Enable',	''),
(78,	'FRY RICE',	'MUTTON FRY RICE',	280.00,	'Enable',	''),
(79,	'FRY RICE',	'PORK FRY RICE',	270.00,	'Enable',	''),
(80,	'FRY RICE',	'MIX FRY RICE',	320.00,	'Enable',	''),
(81,	'FRY RICE',	'VEG ZINGER FRY RICE',	250.00,	'Enable',	''),
(82,	'FRY RICE',	'CHICKEN ZINGER FRY RICE',	280.00,	'Enable',	''),
(83,	'FRY RICE',	'MUTTON ZINGER FRY RICE',	300.00,	'Enable',	''),
(84,	'FRY RICE',	'PORK ZINGER FRY RICE',	320.00,	'Enable',	''),
(85,	'FRY RICE',	'MIX ZINGER FRY RICE',	350.00,	'Enable',	''),
(86,	'FRY RICE',	'VEG MANCHURIAN FRY RICE',	280.00,	'Enable',	''),
(87,	'FRY RICE',	'CHICKEN MANCHURIAN FRY RICE',	300.00,	'Enable',	''),
(88,	'FRY RICE',	'MUTTON MANCHURIAN FRY RICE',	350.00,	'Enable',	''),
(89,	'FRY RICE',	'PORK MANCHURIAN FRY RICE',	330.00,	'Enable',	''),
(90,	'FRY RICE',	'MIX MANCHURIAN FRY RICE',	350.00,	'Enable',	''),
(91,	'BIRYANI',	'CHICKEN BIRYANI',	350.00,	'Enable',	''),
(92,	'BIRYANI',	'EGG BIRYANI',	250.00,	'Enable',	''),
(93,	'BIRYANI',	'VEG BIRYANI',	230.00,	'Enable',	''),
(94,	'ROOL',	'CHICKEN SPRINGROOL',	380.00,	'Enable',	''),
(95,	'ROOL',	'VEG SPRINGROOL',	350.00,	'Enable',	''),
(96,	'SIZLER',	'MUTTON SIZLER',	780.00,	'Enable',	''),
(97,	'SIZLER',	'CHICKEN SIZLER',	750.00,	'Enable',	''),
(98,	'SIZLER',	'PORK SIZLER',	700.00,	'Enable',	''),
(99,	'SIZLER',	'VEG SIZLER',	650.00,	'Enable',	''),
(100,	'PULAO',	'CHICKEN PULAO',	400.00,	'Enable',	''),
(101,	'PULAO',	'VEG PULAO',	350.00,	'Enable',	''),
(102,	'PULAO',	'JEERA PULAO',	380.00,	'Enable',	''),
(103,	'CHOPSI',	'VEG AMERICAN CHOPSI',	280.00,	'Enable',	''),
(104,	'CHOPSI',	'CHICKEN AMERICAN CHOPSI',	300.00,	'Enable',	''),
(105,	'CHOPSI',	'VEG CHINESE CHOPSI',	280.00,	'Enable',	''),
(106,	'CHOPSI',	'CHICKEN CHINESE CHOPSI',	300.00,	'Enable',	''),
(107,	'NEPALI SPECIAL NON VEG SNACKS',	'CHICKEN SEKUWA',	380.00,	'Enable',	''),
(108,	'NEPALI SPECIAL NON VEG SNACKS',	'CHICKEN FRY',	380.00,	'Enable',	''),
(109,	'NEPALI SPECIAL NON VEG SNACKS',	'CHICKEN SADEKO',	330.00,	'Enable',	''),
(110,	'NEPALI SPECIAL NON VEG SNACKS',	'CHICKEN DAMEKO',	400.00,	'Enable',	''),
(111,	'NEPALI SPECIAL NON VEG SNACKS',	'CHICKEN ROAST',	400.00,	'Enable',	''),
(112,	'NEPALI SPECIAL NON VEG SNACKS',	'CHICKEN BOILED',	300.00,	'Enable',	''),
(113,	'NEPALI SPECIAL NON VEG SNACKS',	'PORK SEKUWA',	350.00,	'Enable',	''),
(114,	'NEPALI SPECIAL NON VEG SNACKS',	'PORK DAMEKO',	380.00,	'Enable',	''),
(115,	'NEPALI SPECIAL NON VEG SNACKS',	'PORK FRY',	350.00,	'Enable',	''),
(116,	'NEPALI SPECIAL NON VEG SNACKS',	'TITE LOCAL FISH',	500.00,	'Enable',	''),
(117,	'NEPALI SPECIAL NON VEG SNACKS',	'MUTTON BOILED',	400.00,	'Enable',	''),
(118,	'NEPALI SPECIAL NON VEG SNACKS',	'MUTTON SEKUWA',	450.00,	'Enable',	''),
(119,	'NEPALI SPECIAL NON VEG SNACKS',	'MUTTON FRY',	450.00,	'Enable',	''),
(120,	'NEPALI SPECIAL NON VEG SNACKS',	'LOCAL CHICKEN GRAVY',	350.00,	'Enable',	''),
(121,	'NEPALI SPECIAL VEG SNACKS',	'ALOO SADEKO',	250.00,	'Enable',	''),
(122,	'NEPALI SPECIAL VEG SNACKS',	'VEG PAKODA',	250.00,	'Enable',	''),
(123,	'NEPALI SPECIAL VEG SNACKS',	'EGG PAKODA',	200.00,	'Enable',	''),
(124,	'NEPALI SPECIAL VEG SNACKS',	'KAJU FRY',	380.00,	'Enable',	''),
(125,	'NEPALI SPECIAL VEG SNACKS',	'PANEER PAKODA',	350.00,	'Enable',	''),
(126,	'NEPALI SPECIAL VEG SNACKS',	'PINUT SADEKO',	250.00,	'Enable',	''),
(127,	'NEPALI SPECIAL VEG SNACKS',	'VATMAS SADEKO',	220.00,	'Enable',	''),
(128,	'NEPALI SPECIAL VEG SNACKS',	'MASALA PAPAD',	220.00,	'Enable',	''),
(129,	'NEPALI SPECIAL VEG SNACKS',	'PROUN CHIPS',	180.00,	'Enable',	''),
(130,	'NEPALI SPECIAL VEG SNACKS',	'DRY PAPAD',	30.00,	'Enable',	''),
(131,	'MAIN COURSE NON VEG SNACKS',	'CHICKEN CHILLY',	450.00,	'Enable',	''),
(132,	'MAIN COURSE NON VEG SNACKS',	'CHICKEN MANCHURAION',	380.00,	'Enable',	''),
(133,	'MAIN COURSE NON VEG SNACKS',	'CHICKEN DRUMASTICKS',	380.00,	'Enable',	''),
(134,	'MAIN COURSE NON VEG SNACKS',	'CHICKEN LOLIPOP',	380.00,	'Enable',	''),
(135,	'MAIN COURSE NON VEG SNACKS',	'CHICKEN CRISPY',	450.00,	'Enable',	''),
(136,	'MAIN COURSE NON VEG SNACKS',	'PORK CHILLY',	350.00,	'Enable',	''),
(137,	'MAIN COURSE NON VEG SNACKS',	'TITE FISH',	500.00,	'Enable',	''),
(138,	'MAIN COURSE NON VEG SNACKS',	'MUTTON CHILLY',	400.00,	'Enable',	''),
(139,	'MAIN COURSE NON VEG SNACKS',	'MUTTON PAPER',	450.00,	'Enable',	''),
(140,	'MAIN COURSE NON VEG SNACKS',	'STEAM FISH FULL',	1000.00,	'Enable',	''),
(141,	'MAIN COURSE VEG SNACKS',	'MUSHROOM CHILLY',	300.00,	'Enable',	''),
(142,	'MAIN COURSE VEG SNACKS',	'VEG MANCHURIAN FRY FRY',	350.00,	'Enable',	''),
(143,	'MAIN COURSE VEG SNACKS',	'PANEER CHILLY',	380.00,	'Enable',	''),
(144,	'MAIN COURSE VEG SNACKS',	'GOLDEN FRY BABYCORN',	350.00,	'Enable',	''),
(145,	'MAIN COURSE VEG SNACKS',	'ALLO JEERA',	220.00,	'Enable',	''),
(146,	'MAIN COURSE NON VEG CURRY',	'MUTTON CURRY',	280.00,	'Enable',	''),
(147,	'MAIN COURSE NON VEG CURRY',	'CHICKEN CURRY LOCAL',	300.00,	'Enable',	''),
(148,	'MAIN COURSE NON VEG CURRY',	'PORK CURRY',	260.00,	'Enable',	''),
(149,	'MAIN COURSE NON VEG CURRY',	'KADAI CHICKEN',	350.00,	'Enable',	''),
(150,	'MAIN COURSE NON VEG CURRY',	'CHICKEN BUTTER MASALA',	380.00,	'Enable',	''),
(151,	'MAIN COURSE VEG CURRY',	'PANEER MAKHANI',	450.00,	'Enable',	''),
(152,	'MAIN COURSE VEG CURRY',	'KADAI PANEER',	300.00,	'Enable',	''),
(153,	'MAIN COURSE VEG CURRY',	'MOTER PANEER',	350.00,	'Enable',	''),
(154,	'MAIN COURSE VEG CURRY',	'MIX VEG CURRY',	280.00,	'Enable',	''),
(155,	'MAIN COURSE VEG CURRY',	'PALAK PANEER',	350.00,	'Enable',	''),
(156,	'MAIN COURSE VEG CURRY',	'YALLO DAL TADKA',	250.00,	'Enable',	''),
(157,	'Cold drinks',	'Sprite 500ml',	200.00,	'Enable',	''),
(158,	'Cold drinks',	'Cocacola 500ml',	200.00,	'Enable',	''),
(159,	'Cold drinks',	'Mix juice',	180.00,	'Enable',	''),
(160,	'Cold drinks',	'Redbull',	200.00,	'Enable',	''),
(161,	'Cold drinks',	'Xtreme',	220.00,	'Enable',	''),
(162,	'Cold drinks',	'Orginal redbull',	380.00,	'Enable',	''),
(163,	'Cold drinks',	'Pinepal drinks',	180.00,	'Enable',	''),
(164,	'Cold drinks',	'Mango drinks',	180.00,	'Enable',	''),
(165,	'MAIN COURSE VEG SNACKS',	'Vatams sadako',	300.00,	'Enable',	''),
(166,	'Cold drinks',	'Tuborg beer',	650.00,	'Enable',	''),
(167,	'SET KHANA',	'boiler chicken khana',	500.00,	'Enable',	''),
(168,	'Cold drinks',	'Miniral water',	50.00,	'Enable',	''),
(169,	'ROOL',	'khukari rum 750ml',	3800.00,	'Enable',	'');

DROP TABLE IF EXISTS `order_item_table`;
CREATE TABLE `order_item_table` (
  `order_item_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `product_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `product_quantity` int NOT NULL,
  `product_rate` decimal(12,2) NOT NULL,
  `product_amount` decimal(12,2) NOT NULL,
  PRIMARY KEY (`order_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `order_item_table` (`order_item_id`, `order_id`, `product_name`, `product_quantity`, `product_rate`, `product_amount`) VALUES
(45,	35,	'HOT AND SOUR SOUP VEG',	1,	220.00,	220.00),
(46,	35,	'HOT AND SOUR SOUP CHICKEN',	1,	250.00,	250.00),
(47,	36,	'PORK CURRY',	2,	260.00,	520.00),
(48,	36,	'VEG SET KHANA with ghee',	3,	300.00,	900.00),
(50,	38,	'MUSHROOM SOUP CHICKEN',	4,	220.00,	880.00),
(51,	39,	'CHICKEN SET KHANA LOCAL',	4,	500.00,	2000.00),
(52,	40,	'MUTTON SET KHANA',	2,	500.00,	1000.00),
(53,	41,	'VEG SET KHANA with ghee',	7,	300.00,	2100.00),
(54,	42,	'VEG SET KHANA with ghee',	9,	300.00,	2700.00),
(55,	43,	'Sprite 500ml',	1,	200.00,	200.00),
(56,	44,	'Sprite 500ml',	5,	200.00,	1000.00),
(57,	45,	'fanta 500ml',	2,	200.00,	400.00),
(62,	48,	'NEPALI SALAD',	1,	180.00,	180.00);

DROP TABLE IF EXISTS `order_table`;
CREATE TABLE `order_table` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `order_number` varchar(30) COLLATE utf8mb3_unicode_ci NOT NULL,
  `order_table` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `order_gross_amount` decimal(12,2) NOT NULL,
  `order_tax_amount` decimal(12,2) NOT NULL,
  `order_net_amount` decimal(12,2) NOT NULL,
  `order_date` date NOT NULL,
  `order_time` time NOT NULL,
  `order_waiter` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `order_cashier` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `order_status` enum('In Process','Completed') COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `order_table` (`order_id`, `order_number`, `order_table`, `order_gross_amount`, `order_tax_amount`, `order_net_amount`, `order_date`, `order_time`, `order_waiter`, `order_cashier`, `order_status`) VALUES
(35,	'100000',	'A1',	470.00,	0.00,	470.00,	'2025-05-13',	'20:48:48',	'Master',	'Master',	'Completed'),
(36,	'100001',	'hall2',	1420.00,	0.00,	1420.00,	'2025-05-11',	'17:46:10',	'Master',	'Master',	'Completed'),
(37,	'100002',	'A2',	0.00,	0.00,	0.00,	'2025-05-11',	'17:45:43',	'Master',	'Master',	'Completed'),
(38,	'100003',	'B2',	880.00,	0.00,	880.00,	'2025-05-13',	'20:53:27',	'Master',	'Master',	'Completed'),
(39,	'100004',	'A3',	2000.00,	0.00,	2000.00,	'2025-05-13',	'20:49:59',	'Master',	'Master',	'Completed'),
(40,	'100005',	'A1',	1000.00,	0.00,	1000.00,	'2025-05-13',	'20:53:02',	'Master',	'Master',	'Completed'),
(41,	'100006',	'A1',	2100.00,	273.00,	2373.00,	'2025-05-16',	'11:11:17',	'Master',	'Master',	'Completed'),
(42,	'100007',	'A1',	2700.00,	351.00,	3051.00,	'2025-05-17',	'12:37:53',	'Master',	'Master',	'Completed'),
(43,	'100008',	'A1',	200.00,	26.00,	226.00,	'2025-05-21',	'13:54:15',	'Master',	'Master',	'Completed'),
(44,	'100009',	'A1',	1000.00,	130.00,	1130.00,	'2025-05-21',	'13:51:05',	'Master',	'Master',	'Completed'),
(45,	'100010',	'A2',	400.00,	52.00,	452.00,	'2025-05-21',	'13:56:45',	'Master',	'Master',	'Completed'),
(48,	'100011',	'A2',	0.00,	0.00,	0.00,	'2025-05-25',	'21:08:59',	'Master',	'',	'In Process');

DROP TABLE IF EXISTS `order_tax_table`;
CREATE TABLE `order_tax_table` (
  `order_tax_table_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `order_tax_name` varchar(200) COLLATE utf8mb3_unicode_ci NOT NULL,
  `order_tax_percentage` decimal(4,2) NOT NULL,
  `order_tax_amount` decimal(12,2) NOT NULL,
  PRIMARY KEY (`order_tax_table_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `order_tax_table` (`order_tax_table_id`, `order_id`, `order_tax_name`, `order_tax_percentage`, `order_tax_amount`) VALUES
(124,	36,	'NoTax',	0.00,	0.00),
(129,	37,	'NoTax',	0.00,	0.00),
(133,	40,	'NoTax',	0.00,	0.00),
(134,	39,	'NoTax',	0.00,	0.00),
(135,	38,	'NoTax',	0.00,	0.00),
(137,	35,	'NoTax',	0.00,	0.00),
(138,	41,	'Tax',	13.00,	273.00),
(140,	42,	'Tax',	13.00,	351.00),
(160,	44,	'Tax',	13.00,	130.00),
(161,	43,	'Tax',	13.00,	26.00),
(162,	45,	'Tax',	13.00,	52.00);

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `category_id` int DEFAULT NULL,
  `quantity` int DEFAULT '0',
  `product_status` varchar(20) COLLATE utf8mb4_general_ci DEFAULT 'Enable',
  `product_price` decimal(11,0) DEFAULT NULL,
  `product_image` varchar(2000) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `products` (`product_id`, `product_name`, `category_id`, `quantity`, `product_status`, `product_price`, `product_image`) VALUES
(10,	'Vodka',	4,	12,	'Enable',	400,	''),
(11,	'tuborg beer',	4,	60,	'Enable',	650,	''),
(12,	'tuborg beer 330ml',	4,	24,	'Enable',	300,	''),
(13,	'redbull',	7,	48,	'Enable',	350,	''),
(14,	'barasinga beer',	4,	96,	'Enable',	300,	''),
(19,	'xtrem',	7,	24,	'Enable',	200,	''),
(21,	'sprite 500ml',	9,	24,	'Enable',	200,	''),
(22,	'fanta 500ml',	9,	12,	'Enable',	200,	''),
(23,	'Redlevel',	17,	1,	'Enable',	10500,	''),
(24,	'Dovel black level',	17,	1,	'Enable',	13500,	''),
(25,	'Black level',	17,	2,	'Enable',	12500,	''),
(26,	'Jack Daniel',	17,	1,	'Enable',	11000,	''),
(27,	'Red signature',	17,	1,	'Enable',	4800,	''),
(28,	'Khukari rum',	16,	6,	'Enable',	3600,	''),
(29,	'Bigmasrer R',	10,	3,	'Enable',	1300,	'');

DROP TABLE IF EXISTS `reservation_data`;
CREATE TABLE `reservation_data` (
  `reservation_id` int NOT NULL AUTO_INCREMENT,
  `reservation_number` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `customer_phone` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `customer_address` text COLLATE utf8mb4_general_ci NOT NULL,
  `gross_amount` decimal(10,2) NOT NULL,
  `tax_amount` decimal(10,2) NOT NULL,
  `net_amount` decimal(10,2) NOT NULL,
  `reservation_status` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `reservation_created_by` int NOT NULL,
  `reservation_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `billing_status` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'In Progress',
  `payment_method` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `discount_amount` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`reservation_id`),
  UNIQUE KEY `reservation_number` (`reservation_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `reservation_data` (`reservation_id`, `reservation_number`, `customer_name`, `customer_phone`, `customer_address`, `gross_amount`, `tax_amount`, `net_amount`, `reservation_status`, `reservation_created_by`, `reservation_created_at`, `billing_status`, `payment_method`, `discount_amount`) VALUES
(23,	'RES-2505-8799',	'201/202',	'9852680015',	'Phungling 5 Buddha Chowk',	22900.00,	1145.00,	22842.75,	'Checked Out',	3,	'2025-05-04 07:30:28',	'Completed',	'Cash',	'1202.25'),
(25,	'RES-2505-9970',	'Indra sherpa',	'6655',	'Taplejung ',	17600.00,	880.00,	11980.00,	'Checked Out',	3,	'2025-05-14 09:27:25',	'Completed',	'Cash',	'0'),
(26,	'RES-2505-3737',	'Megnath dhungana ',	'9852680015',	'Ilam',	11371.43,	568.57,	11940.00,	'Checked Out',	3,	'2025-05-15 02:56:14',	'Completed',	'Cash',	'0'),
(30,	'RES-2505-0430',	'Drivar sir',	'9841046094',	'Taplejung',	3190.48,	159.52,	3350.00,	'Checked Out',	3,	'2025-05-15 03:00:01',	'Completed',	'Cash',	'0'),
(34,	'RES-2505-1385',	'Yalumber nembang',	'9701858903',	'Pachthar embung',	5900.00,	0.00,	5900.00,	'Checked Out',	3,	'2025-05-16 15:01:33',	'Completed',	'Cash',	'0'),
(48,	'RES-2505-9705',	'Pasang sharpa',	'9803560285',	'Jorpathi ktm',	14000.00,	0.00,	14000.00,	'Checked Out',	3,	'2025-05-18 13:21:40',	'Completed',	'Cash',	'0'),
(49,	'RES-2505-9068',	'megnath dhungana',	'9852680015',	'ilam',	8550.00,	0.00,	8550.00,	'Checked Out',	3,	'2025-05-18 13:25:55',	'Completed',	'Cash',	'0'),
(70,	'RES-2505-0537',	'ram naupana',	'9851099814',	'ktm',	6000.00,	0.00,	6000.00,	'Checked Out',	3,	'2025-05-18 14:32:56',	'Completed',	'Cash',	'0'),
(71,	'RES-2505-1860',	'Rokesh maskey',	'9860118267',	'Sansavarsava',	32000.00,	0.00,	32000.00,	'Checked Out',	3,	'2025-05-18 17:21:02',	'Completed',	'Cash',	'0'),
(72,	'RES-2505-4694',	'Chinesh ',	'6666',	'Chaina',	8280.00,	0.00,	8280.00,	'Checked Out',	3,	'2025-05-19 17:04:07',	'Completed',	'Cash',	'0'),
(73,	'RES-2505-5808',	'Pradip dhakal',	'9841255732',	'Gorkha',	2250.00,	0.00,	2250.00,	'Checked Out',	3,	'2025-05-19 17:06:10',	'Completed',	'Cash',	'0'),
(74,	'RES-2505-1859',	'Garesh chaudari ',	'9819702585',	'Ktm',	4000.00,	0.00,	4000.00,	'Checked Out',	3,	'2025-05-19 17:07:18',	'Completed',	'Cash',	'0'),
(75,	'RES-2505-3523',	'Ram naupana ',	'9841046094',	'Ktm',	11000.00,	0.00,	11000.00,	'Checked Out',	3,	'2025-05-20 12:11:00',	'Completed',	'Cash',	'0'),
(76,	'RES-2505-4407',	'Ganesh Chaudhari',	'9819702585',	'Ktm',	3000.00,	0.00,	3000.00,	'Checked Out',	3,	'2025-05-20 12:12:17',	'Completed',	'Cash',	'0'),
(77,	'RES-2505-5782',	'Prdip kumar karki',	'9802725403',	'Ktm',	6900.00,	0.00,	6900.00,	'Checked Out',	3,	'2025-05-21 13:46:23',	'Completed',	'Online',	'0'),
(78,	'RES-2505-6090',	'dawa sherpa ',	'9851094990',	'ktm',	38500.00,	0.00,	38500.00,	'Checked Out',	3,	'2025-05-22 07:50:47',	'Completed',	'Online',	'0'),
(79,	'RES-2505-3708',	'dawa sherpa ',	'9851094990',	'ktm',	38700.00,	0.00,	38700.00,	'Checked Out',	3,	'2025-05-22 07:55:42',	'Completed',	'Cash',	'0'),
(80,	'RES-2505-7630',	'megnath dhungana',	'9852680015',	'ilam',	6000.00,	0.00,	6000.00,	'Checked Out',	3,	'2025-05-22 08:01:56',	'Completed',	'Cash',	'0'),
(81,	'RES-2505-9919',	'BIRATE PURI',	'9861571016',	'Dang',	3500.00,	0.00,	3500.00,	'Checked In',	3,	'2025-05-27 13:58:47',	'In Progress',	NULL,	NULL),
(82,	'RES-2505-5091',	'Nishan khadka',	'9816052625',	'Jhapa kharkha',	4750.00,	0.00,	4750.00,	'Checked In',	3,	'2025-05-28 09:57:11',	'In Progress',	NULL,	NULL);

DROP TABLE IF EXISTS `reservation_room`;
CREATE TABLE `reservation_room` (
  `reservation_room_id` int NOT NULL AUTO_INCREMENT,
  `reservation_id` int NOT NULL,
  `room_id` int NOT NULL,
  `check_in_datetime` datetime DEFAULT NULL,
  `check_out_datetime` datetime DEFAULT NULL,
  `days` int DEFAULT NULL,
  PRIMARY KEY (`reservation_room_id`),
  KEY `reservation_id` (`reservation_id`),
  KEY `room_id` (`room_id`),
  CONSTRAINT `reservation_room_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `reservation_data` (`reservation_id`),
  CONSTRAINT `reservation_room_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `room_data` (`room_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `reservation_room` (`reservation_room_id`, `reservation_id`, `room_id`, `check_in_datetime`, `check_out_datetime`, `days`) VALUES
(60,	23,	10,	'2025-05-15 12:04:52',	'2025-05-15 12:04:52',	3),
(61,	23,	11,	NULL,	NULL,	3),
(64,	26,	8,	NULL,	NULL,	1),
(65,	26,	10,	NULL,	NULL,	1),
(69,	30,	7,	NULL,	NULL,	1),
(79,	25,	11,	NULL,	NULL,	1),
(80,	25,	15,	NULL,	'2025-05-16 12:04:52',	1),
(83,	34,	15,	'2025-05-16 14:00:00',	'2025-05-17 08:33:03',	1),
(99,	49,	7,	'2025-05-18 14:00:00',	'2025-05-19 22:24:26',	1),
(100,	49,	10,	'2025-05-18 14:00:00',	'2025-05-19 22:24:26',	1),
(121,	70,	11,	'2025-05-18 14:00:00',	'2025-05-19 23:52:29',	1),
(122,	70,	14,	'2025-05-18 14:00:00',	'2025-05-19 23:52:29',	1),
(127,	72,	10,	'2025-05-19 14:00:00',	'2025-05-20 08:13:02',	1),
(128,	72,	12,	'2025-05-19 14:00:00',	'2025-05-20 08:13:02',	1),
(134,	73,	7,	'2025-05-19 14:00:00',	'2025-05-20 08:13:46',	1),
(136,	74,	11,	'2025-05-19 14:00:00',	'2025-05-20 17:55:04',	1),
(142,	71,	3,	'2025-05-18 14:00:00',	'2025-05-20 08:12:25',	1),
(143,	71,	4,	'2025-05-19 14:00:00',	'2025-05-20 08:12:25',	1),
(144,	71,	5,	'2025-05-18 14:00:00',	'2025-05-20 08:12:25',	1),
(145,	71,	6,	'2025-05-18 14:00:00',	'2025-05-20 08:12:25',	1),
(146,	71,	9,	'2025-05-18 14:00:00',	'2025-05-20 08:12:25',	1),
(149,	48,	13,	'2025-05-18 14:00:00',	'2025-05-20 08:37:53',	1),
(150,	48,	15,	'2025-05-18 14:00:00',	'2025-05-20 08:37:53',	1),
(155,	76,	14,	'2025-05-20 14:00:00',	'2025-05-21 09:47:40',	1),
(156,	75,	4,	'2025-05-20 14:00:00',	'2025-05-21 09:47:48',	1),
(157,	75,	11,	'2025-05-20 14:00:00',	'2025-05-21 09:47:48',	1),
(158,	77,	3,	'2025-05-21 14:00:00',	'2025-05-22 13:39:13',	1),
(159,	77,	13,	'2025-05-21 14:00:00',	'2025-05-22 13:39:13',	1),
(166,	78,	7,	'2025-05-22 14:00:00',	'2025-05-22 13:38:38',	1),
(167,	78,	10,	'2025-05-22 14:00:00',	'2025-05-22 13:38:38',	1),
(168,	78,	11,	'2025-05-22 14:00:00',	'2025-05-22 13:38:38',	1),
(169,	78,	12,	'2025-05-22 14:00:00',	'2025-05-22 13:38:38',	1),
(170,	78,	14,	'2025-05-22 14:00:00',	'2025-05-22 13:38:38',	1),
(171,	78,	15,	'2025-05-22 14:00:00',	'2025-05-22 13:38:38',	1),
(177,	79,	7,	'2025-05-22 14:00:00',	'2025-05-24 10:06:03',	1),
(178,	79,	10,	'2025-05-22 14:00:00',	'2025-05-24 10:06:03',	1),
(179,	79,	11,	'2025-05-22 14:00:00',	'2025-05-24 10:06:03',	1),
(180,	79,	12,	'2025-05-22 14:00:00',	'2025-05-24 10:06:03',	1),
(181,	79,	14,	'2025-05-22 14:00:00',	'2025-05-24 10:06:03',	1),
(182,	79,	15,	'2025-05-22 14:00:00',	'2025-05-24 10:06:03',	1),
(183,	80,	8,	'2025-05-22 14:00:00',	'2025-05-24 10:05:48',	1),
(184,	80,	13,	'2025-05-22 14:00:00',	'2025-05-24 10:05:48',	1),
(185,	81,	13,	'2025-05-27 14:00:00',	'2025-05-28 12:00:00',	1),
(186,	82,	7,	'2025-05-28 14:00:00',	'2025-05-29 12:00:00',	1),
(187,	82,	8,	'2025-05-28 14:00:00',	'2025-05-29 12:00:00',	1);

DROP TABLE IF EXISTS `restaurant_table`;
CREATE TABLE `restaurant_table` (
  `restaurant_id` int NOT NULL AUTO_INCREMENT,
  `restaurant_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `restaurant_tag_line` varchar(300) COLLATE utf8mb3_unicode_ci NOT NULL,
  `restaurant_address` text COLLATE utf8mb3_unicode_ci NOT NULL,
  `restaurant_contact_no` varchar(30) COLLATE utf8mb3_unicode_ci NOT NULL,
  `restaurant_email` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `restaurant_currency` varchar(10) COLLATE utf8mb3_unicode_ci NOT NULL,
  `restaurant_timezone` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `restaurant_logo` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`restaurant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `restaurant_table` (`restaurant_id`, `restaurant_name`, `restaurant_tag_line`, `restaurant_address`, `restaurant_contact_no`, `restaurant_email`, `restaurant_currency`, `restaurant_timezone`, `restaurant_logo`) VALUES
(1,	'The Hotel Mountain',	'+977-024460931',	'Phungling Bazaar, Taplejuhg',	'+977-9852660931',	'thehotelmountain@gmail.com',	'NPR',	'Asia/Katmandu',	'images/118745801.png');

DROP TABLE IF EXISTS `room_data`;
CREATE TABLE `room_data` (
  `room_id` int NOT NULL AUTO_INCREMENT,
  `room_number` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `room_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `price_per_day` decimal(10,2) NOT NULL,
  `room_status` enum('Available','Reserved','Occupied') COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`room_id`),
  UNIQUE KEY `room_number` (`room_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `room_data` (`room_id`, `room_number`, `room_type`, `price_per_day`, `room_status`) VALUES
(3,	'101',	'Double',	2500.00,	'Available'),
(4,	'102',	'Double',	2500.00,	'Available'),
(5,	'103',	'Double',	2500.00,	'Available'),
(6,	'104',	'Double',	2500.00,	'Available'),
(7,	'105',	'Single',	2250.00,	'Occupied'),
(8,	'106',	'Double',	2500.00,	'Occupied'),
(9,	'107',	'Single',	1200.00,	'Available'),
(10,	'201',	'Suite',	4500.00,	'Available'),
(11,	'202',	'Double',	3000.00,	'Available'),
(12,	'203',	'Double',	3000.00,	'Available'),
(13,	'204',	'Deluxe',	3500.00,	'Occupied'),
(14,	'205',	'Double',	3000.00,	'Available'),
(15,	'206',	'Deluxe',	3500.00,	'Available'),
(16,	'301',	'Double',	1500.00,	'Available'),
(17,	'302',	'Double',	1000.00,	'Available'),
(18,	'303',	'Executive',	1000.00,	'Available'),
(19,	'304',	'Double',	1000.00,	'Available');

DROP TABLE IF EXISTS `room_order`;
CREATE TABLE `room_order` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `order_number` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `reservation_id` int NOT NULL,
  `order_gross_amount` decimal(12,2) NOT NULL,
  `order_tax_amount` decimal(12,2) NOT NULL,
  `order_net_amount` decimal(12,2) NOT NULL,
  `order_date` date NOT NULL,
  `order_time` time NOT NULL,
  `order_waiter` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `order_cashier` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `order_status` enum('In Process','Completed') CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `fk_reservation` (`reservation_id`),
  CONSTRAINT `fk_reservation` FOREIGN KEY (`reservation_id`) REFERENCES `reservation_data` (`reservation_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `room_order` (`order_id`, `order_number`, `reservation_id`, `order_gross_amount`, `order_tax_amount`, `order_net_amount`, `order_date`, `order_time`, `order_waiter`, `order_cashier`, `order_status`) VALUES
(7,	'100001',	23,	0.00,	0.00,	0.00,	'2025-05-04',	'17:42:30',	'Master',	'Master',	'Completed'),
(8,	'100006',	25,	5480.00,	0.00,	5480.00,	'2025-05-14',	'15:21:02',	'Master',	'Master',	'Completed'),
(9,	'100006',	26,	4940.00,	0.00,	4940.00,	'2025-05-15',	'08:42:34',	'Master',	'Master',	'Completed'),
(10,	'100006',	30,	0.00,	0.00,	0.00,	'2025-05-15',	'08:50:23',	'Master',	'Master',	'Completed'),
(11,	'100007',	34,	0.00,	0.00,	0.00,	'2025-05-16',	'20:50:59',	'Master',	'Master',	'Completed'),
(12,	'100007',	34,	0.00,	0.00,	0.00,	'2025-05-16',	'20:50:59',	'Master',	'Master',	'Completed'),
(13,	'100008',	49,	0.00,	0.00,	0.00,	'2025-05-18',	'19:30:34',	'Master',	'Master',	'Completed'),
(14,	'100008',	71,	0.00,	0.00,	0.00,	'2025-05-18',	'23:07:05',	'Master',	'Master',	'Completed'),
(15,	'100008',	74,	0.00,	0.00,	0.00,	'2025-05-19',	'23:57:41',	'Master',	'Master',	'Completed'),
(16,	'100008',	72,	0.00,	0.00,	0.00,	'2025-05-19',	'23:59:07',	'Master',	'Master',	'Completed'),
(17,	'100011',	77,	0.00,	0.00,	0.00,	'2025-05-21',	'19:56:21',	'Master',	'Master',	'Completed'),
(18,	'100011',	79,	0.00,	0.00,	0.00,	'2025-05-22',	'13:48:51',	'Master',	'Master',	'Completed');

DROP TABLE IF EXISTS `room_order_item`;
CREATE TABLE `room_order_item` (
  `order_item_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `product_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `product_quantity` int NOT NULL,
  `product_rate` decimal(12,2) NOT NULL,
  `product_amount` decimal(12,2) NOT NULL,
  `scheduled_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `room_order_item_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `room_order` (`order_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `room_order_item` (`order_item_id`, `order_id`, `product_name`, `product_quantity`, `product_rate`, `product_amount`, `scheduled_datetime`) VALUES
(15,	7,	'BLACK COFFEE',	4,	100.00,	400.00,	'2025-05-04 17:57:00'),
(16,	8,	'Redbull',	1,	200.00,	200.00,	NULL),
(19,	8,	'Tuborg beer',	2,	650.00,	1300.00,	NULL),
(20,	8,	'CHICKEN FRY',	1,	380.00,	380.00,	NULL),
(21,	8,	'PORK SET KHANA',	8,	450.00,	3600.00,	NULL),
(22,	9,	'ROTI SET',	1,	350.00,	350.00,	NULL),
(23,	9,	'MUTTON SET KHANA',	1,	500.00,	500.00,	NULL),
(24,	9,	'MILK COFFEE',	2,	120.00,	240.00,	NULL),
(25,	9,	'VEG SET KHANA with ghee',	2,	300.00,	600.00,	NULL),
(26,	10,	'CHICKEN CHILLY',	1,	450.00,	450.00,	'2025-05-15 09:04:00'),
(27,	10,	'Tuborg beer',	1,	650.00,	650.00,	'2025-05-15 09:04:00'),
(28,	9,	'PORK SET KHANA',	7,	450.00,	3150.00,	NULL),
(29,	9,	'BLACK COFFEE',	1,	100.00,	100.00,	NULL),
(30,	11,	'VEG SET KHANA with ghee',	4,	300.00,	1200.00,	NULL),
(31,	12,	'VEG SET KHANA with ghee',	4,	300.00,	1200.00,	NULL),
(32,	13,	'ROTI SET',	2,	350.00,	700.00,	NULL),
(33,	13,	'CHICKEN SET KHANA LOCAL with ghee and cord',	2,	550.00,	1100.00,	NULL),
(34,	14,	'VEG SET KHANA with ghee',	16,	300.00,	4800.00,	NULL),
(35,	14,	'VEG SET KHANA with ghee',	16,	300.00,	4800.00,	NULL),
(36,	15,	'CHICKEN SET KHANA LOCAL',	2,	500.00,	1000.00,	NULL),
(37,	16,	'MUTTON SIZLER',	1,	780.00,	780.00,	NULL),
(38,	17,	'VEG SET KHANA with ghee',	3,	300.00,	900.00,	NULL),
(39,	18,	'Miniral water',	4,	50.00,	200.00,	NULL);

DROP TABLE IF EXISTS `table_data`;
CREATE TABLE `table_data` (
  `table_id` int NOT NULL AUTO_INCREMENT,
  `table_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `table_capacity` int NOT NULL,
  `table_status` enum('Enable','Disable') COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`table_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `table_data` (`table_id`, `table_name`, `table_capacity`, `table_status`) VALUES
(11,	'A1',	6,	'Enable'),
(12,	'A2',	4,	'Enable'),
(13,	'A3',	5,	'Enable'),
(14,	'B1',	4,	'Enable'),
(15,	'B2',	4,	'Enable'),
(16,	'hall',	20,	'Enable'),
(17,	'hall1',	10,	'Enable'),
(18,	'hall2',	5,	'Enable');

DROP TABLE IF EXISTS `tax_table`;
CREATE TABLE `tax_table` (
  `tax_id` int NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `tax_percentage` decimal(4,2) NOT NULL,
  `tax_status` enum('Enable','Disable') COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;


DROP TABLE IF EXISTS `user_table`;
CREATE TABLE `user_table` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_name` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_contact_no` varchar(30) COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_email` varchar(30) COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_password` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_profile` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_type` enum('Master','Waiter','Cashier') COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_status` enum('Enable','Disable') COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_created_on` datetime NOT NULL,
  `remember_token` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

INSERT INTO `user_table` (`user_id`, `user_name`, `user_contact_no`, `user_email`, `user_password`, `user_profile`, `user_type`, `user_status`, `user_created_on`, `remember_token`) VALUES
(3,	'Admin',	'9852660931',	'thehotelmountain@gmail.com',	'admin@123',	'images/679378532.png',	'Master',	'Enable',	'2024-08-07 08:52:04',	'da79db6ac39040c2bb26d3252ee177e3'),
(6,	'Waiter',	'9852660931',	'waiter@gmail.com',	'waiter@2',	'images/1723025632.png',	'Waiter',	'Enable',	'2024-08-07 15:58:52',	NULL),
(7,	'Cashier',	'9852660931',	'cashier@gmail.com',	'cashier@1',	'images/1723025656.png',	'Cashier',	'Enable',	'2024-08-07 15:59:16',	NULL),
(8,	'Pawan',	'9745673009',	'pawaan012@gmail.com',	'pawan@123',	'images/679378532.png',	'Master',	'Enable',	'2024-08-07 08:52:04',	'ea7a2dd09bfb091df2cd6586a08ba5ee');

-- 2025-05-28 10:45:41
